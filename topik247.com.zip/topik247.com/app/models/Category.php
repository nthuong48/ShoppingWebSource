<?php

class Category extends BaseModel
{

    /**
     *
     * @var string
     * @Column(column="title", type="string", length=255, nullable=true)
     */
    public $title;
    /**
     *
     * @var string
     * @Column(column="slug", type="string", length=200, nullable=true)
     */
    public $slug;

    /**
     * Initialize method for model.
     */
    public function initialize()
    {
        $this->setSource("category");

        $this->hasMany('id', 'Lessons', 'category_id', [
            'alias' => 'lessons',
            'params' => [
                "status = ".BaseModel::$STATUS_Publish,
                'order' => 'idx ASC'
            ]
        ]);
    }

    /**
     * Returns table name mapped in the model.
     *
     * @return string
     */
    public function getSource()
    {
        return 'category';
    }


}
