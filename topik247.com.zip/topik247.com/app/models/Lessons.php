<?php

class Lessons extends BaseModel
{

    /**
     *
     * @var string
     * @Column(column="body", type="string", length=255, nullable=true)
     */
    public $body;

    /**
     *
     * @var integer
     * @Column(column="category_id", type="integer", length=2, nullable=true)
     */
    public $category_id;

    /**
     *
     * @var integer
     * @Column(column="view", type="integer", length=5, nullable=true)
     */
    public $view;

    /**
     *
     * @var integer
     * @Column(column="numdo", type="integer", length=5, nullable=true)
     */
    public $numdo;

    /**
     *
     * @var string
     * @Column(column="slug", type="string", length=200, nullable=true)
     */
    public $slug;

    /**
     *
     * @var integer
     * @Column(column="icon", type="integer", length=5, nullable=false)
     */
    public $icon;

    /**
     * Initialize method for model.
     */
    public function initialize()
    {
        $this->setSource("lessons");
        $this->hasOne('category_id', 'Category', 'id', [
            'alias' => 'category'
        ]);
        $this->hasMany('id', 'Questions', 'lesson_id', [
            'alias' => 'questions',
            'params' => [
                'order' => 'idx ASC'
            ]
        ]);
    }

    /**
     * Returns table name mapped in the model.
     *
     * @return string
     */
    public function getSource()
    {
        return 'lessons';
    }


    public function findBySlugCategory($slug)
    {
        $data = $this->modelsManager->createBuilder()
            ->from('lessons')
            ->join('category', 'lessons.category_id = category.id')
            ->where('category.slug = "' . $slug . '"')
            ->orderBy('lessons.idx')
            ->getQuery()
            ->execute();
        return $data;
    }
    public function findLesson($slug,$category_slug)
    {
        $data = $this->modelsManager->createBuilder()
            ->from('lessons')
            ->join('category', 'lessons.category_id = category.id')
            ->where('category.slug = "' . $category_slug . '" AND lessons.slug="'.$slug.'"')
            ->orderBy('lessons.idx')
            ->getQuery()
            ->execute();
        return $data;
    }
}
