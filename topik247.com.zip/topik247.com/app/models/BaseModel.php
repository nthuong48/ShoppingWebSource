<?php

class BaseModel extends \Phalcon\Mvc\Model
{

    public static $STATUS_Review = 0;
    public static $STATUS_Publish = 1;

    /**
     *
     * @var integer
     * @Primary
     * @Identity
     * @Column(column="id", type="integer", length=2, nullable=false)
     */
    public $id;

    /**
     *
     * @var integer
     * @Column(column="idx", type="integer", length=2, nullable=true)
     */
    public $idx;

    /**
     *
     * @var integer
     * @Column(column="status", type="integer", length=2, nullable=true)
     */
    public $status;

    /**
     * Allows to query a set of records that match the specified conditions
     *
     * @param mixed $parameters
     * @return Object[]|Object|\Phalcon\Mvc\Model\ResultSetInterface
     */
    public static function find($parameters = null)
    {
        return parent::find($parameters);
    }

    /**
     * Allows to query the first record that match the specified conditions
     *
     * @param mixed $parameters
     * @return Object\Phalcon\Mvc\Model\ResultInterface
     */
    public static function findFirst($parameters = null)
    {
        return parent::findFirst($parameters);
    }

}
