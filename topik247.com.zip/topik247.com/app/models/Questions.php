<?php

class Questions extends BaseModel
{

    /**
     *
     * @var integer
     * @Column(column="lesson_id", type="integer", length=11, nullable=true)
     */
    public $lesson_id;

    /**
     *
     * @var string
     * @Column(column="quota", type="string", length=1000, nullable=true)
     */
    public $quota;

    /**
     *
     * @var string
     * @Column(column="question", type="string", length=500, nullable=true)
     */
    public $question;

    /**
     *
     * @var string
     * @Column(column="body", type="string", nullable=true)
     */
    public $body;

    /**
     *
     * @var string
     * @Column(column="tip", type="string", nullable=true)
     */
    public $tip;

    /**
     *
     * @var integer
     * @Column(column="true_anwser", type="integer", length=2, nullable=true)
     */
    public $true_anwser;

    /**
     * Initialize method for model.
     */
    public function initialize()
    {
        $this->setSource("questions");
        $this->hasMany('id', 'Anwsers', 'question_id', [
            'alias' => 'anwsers',
            'params' => [
//                'order' => 'RAND()'
            ]
        ]);
    }

    /**
     * Returns table name mapped in the model.
     *
     * @return string
     */
    public function getSource()
    {
        return 'questions';
    }

}
