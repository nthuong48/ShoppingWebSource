<?php

class Anwsers extends BaseModel
{

    /**
     *
     * @var integer
     * @Column(column="lesson_id", type="integer", length=11, nullable=true)
     */
    public $lesson_id;

    /**
     *
     * @var integer
     * @Column(column="question_id", type="integer", length=11, nullable=true)
     */
    public $question_id;

    /**
     *
     * @var string
     * @Column(column="body", type="string", nullable=true)
     */
    public $body;

    /**
     * Initialize method for model.
     */
    public function initialize()
    {
        $this->setSource("anwsers");
        $this->belongsTo("question_id", "Questions", "id", array('alias' => 'questions'));
    }

    /**
     * Returns table name mapped in the model.
     *
     * @return string
     */
    public function getSource()
    {
        return 'anwsers';
    }

}
