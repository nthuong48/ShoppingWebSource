<?php

class IndexController extends ControllerBase
{

    public function indexAction()
    {
        $this->title = 'Tổng hợp 300 đề luyện thi topik và bài tập tiếng hàn sơ cấp-trung cấp-cao cấp';
        $this->description = $this->title;
        $this->keywords = 'Tài liệu miễn phí, bộ đề thi, thi thử, luyện tập topik, topik , topik 1, topik 2 , topik i, topik ii, han quoc , du hoc , lao dong';
        $this->baseView();
    }

    public function slugAction()
    {
        $lessons = Lessons::find();
        if(count($lessons) > 0){
            foreach ($lessons as $les){
                $les->slug = to_slug($les->body);
                $les->save();
            }
        }
        $this->view->lessons = $lessons;

        $categoris = Category::find();
        if(count($categoris) > 0){
            foreach ($categoris as $category){
                $category->slug = to_slug($category->title);
                $category->save();
            }
        }
    }
}

