<?php
 
use Phalcon\Mvc\Model\Criteria;
use Phalcon\Paginator\Adapter\Model as Paginator;


class ReportController extends ControllerBase
{
    public function initialize(){
        $this->view->setRenderLevel(\Phalcon\Mvc\View::LEVEL_ACTION_VIEW);
    }
    /**
     * Index action
     */
    public function indexAction()
    {
        $this->persistent->parameters = null;
    }

    /**
     * Searches for report
     */
    public function searchAction()
    {
        $numberPage = 1;
        if ($this->request->isPost()) {
            $query = Criteria::fromInput($this->di, 'Report', $_POST);
            $this->persistent->parameters = $query->getParams();
        } else {
            $numberPage = $this->request->getQuery("page", "int");
        }

        $parameters = $this->persistent->parameters;
        if (!is_array($parameters)) {
            $parameters = [];
        }
        $parameters["order"] = "id";

        $report = Report::find($parameters);
        if (count($report) == 0) {
            $this->flash->notice("The search did not find any report");

            $this->dispatcher->forward([
                "controller" => "report",
                "action" => "index"
            ]);

            return;
        }

        $paginator = new Paginator([
            'data' => $report,
            'limit'=> 10,
            'page' => $numberPage
        ]);

        $this->view->page = $paginator->getPaginate();
    }

    /**
     * Displays the creation form
     */
    public function newAction()
    {

    }

    /**
     * Edits a report
     *
     * @param string $id
     */
    public function editAction($id)
    {
        if (!$this->request->isPost()) {

            $report = Report::findFirstByid($id);
            if (!$report) {
                $this->flash->error("report was not found");

                $this->dispatcher->forward([
                    'controller' => "report",
                    'action' => 'index'
                ]);

                return;
            }

            $this->view->id = $report->id;

            $this->tag->setDefault("id", $report->id);
            $this->tag->setDefault("title", $report->title);
            $this->tag->setDefault("body", $report->body);
            $this->tag->setDefault("email", $report->email);
            $this->tag->setDefault("lesson_id", $report->lesson_id);
            $this->tag->setDefault("created_time", $report->created_time);
            
        }
    }

    /**
     * Creates a new report
     */
    public function createAction()
    {
        if (!$this->request->isPost()) {
            $this->dispatcher->forward([
                'controller' => "report",
                'action' => 'index'
            ]);

            return;
        }

        $report = new Report();
        $report->title = $this->request->getPost("title");
        $report->body = $this->request->getPost("body");
        $report->email = $this->request->getPost("email", "email");
        $report->lessonId = $this->request->getPost("lesson_id");
        $report->createdTime = $this->request->getPost("created_time");
        

        if (!$report->save()) {
            foreach ($report->getMessages() as $message) {
                $this->flash->error($message);
            }

            $this->dispatcher->forward([
                'controller' => "report",
                'action' => 'new'
            ]);

            return;
        }

        $this->flash->success("report was created successfully");

        $this->dispatcher->forward([
            'controller' => "report",
            'action' => 'index'
        ]);
    }

    /**
     * Saves a report edited
     *
     */
    public function saveAction()
    {

        if (!$this->request->isPost()) {
            $this->dispatcher->forward([
                'controller' => "report",
                'action' => 'index'
            ]);

            return;
        }

        $id = $this->request->getPost("id");
        $report = Report::findFirstByid($id);

        if (!$report) {
            $this->flash->error("report does not exist " . $id);

            $this->dispatcher->forward([
                'controller' => "report",
                'action' => 'index'
            ]);

            return;
        }

        $report->title = $this->request->getPost("title");
        $report->body = $this->request->getPost("body");
        $report->email = $this->request->getPost("email", "email");
        $report->lessonId = $this->request->getPost("lesson_id");
        $report->createdTime = $this->request->getPost("created_time");
        

        if (!$report->save()) {

            foreach ($report->getMessages() as $message) {
                $this->flash->error($message);
            }

            $this->dispatcher->forward([
                'controller' => "report",
                'action' => 'edit',
                'params' => [$report->id]
            ]);

            return;
        }

        $this->flash->success("report was updated successfully");

        $this->dispatcher->forward([
            'controller' => "report",
            'action' => 'index'
        ]);
    }

    /**
     * Deletes a report
     *
     * @param string $id
     */
    public function deleteAction($id)
    {
        $report = Report::findFirstByid($id);
        if (!$report) {
            $this->flash->error("report was not found");

            $this->dispatcher->forward([
                'controller' => "report",
                'action' => 'index'
            ]);

            return;
        }

        if (!$report->delete()) {

            foreach ($report->getMessages() as $message) {
                $this->flash->error($message);
            }

            $this->dispatcher->forward([
                'controller' => "report",
                'action' => 'search'
            ]);

            return;
        }

        $this->flash->success("report was deleted successfully");

        $this->dispatcher->forward([
            'controller' => "report",
            'action' => "index"
        ]);
    }

}
