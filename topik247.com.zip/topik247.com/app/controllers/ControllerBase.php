<?php

use Phalcon\Mvc\Controller;

class ControllerBase extends Controller
{

    public $title = '';
    public $description = '';
    public $keywords = '';

    public function initialize()
    {
        //menu
        $categories = Category::find(array(
            "status = ".BaseModel::$STATUS_Publish,
            "order" => "idx"
        ));
        $this->view->categories = $categories;
        $this->baseView();
    }
    public function notFound() {
        $response = new \Phalcon\Http\Response();
        $response->setStatusCode(404, "File not Found");
        $this->view->pick('error/404');
        $this->response->send();
    }

    public function baseView(){
        $this->view->title = $this->title;
        $this->view->description = $this->description;
        $this->view->keywords = $this->keywords;
    }
}
