<?php

use Phalcon\Http\Request;

class LessonsController extends ControllerBase
{

    public function listAction()
    {
        $slug = $this->dispatcher->getParam('category_slug');
        $this->view->category_slug = $slug;
        $category = Category::findFirst('slug="' . $slug . '"');
        if ($category == null) {
            $this->notFound();
            return;
        }
        $this->view->category = $category;
        $this->view->lessons = $category->lessons;

        $this->title = $category->title . ' | Luyện tập ' . $category->title . ' | Trắc nghiệm ' . $category->title . ' hay nhất tại lovekorean';
        $this->description = $this->title . ' - Tuyển tập các bài ôn luyện ' . $category->title . ' tốt nhất dành cho du học sinh, lao động hàn quốc, luyện thi ' . $category->title;
        $this->keywords = 'Tài liệu miễn phí, bộ đề thi, thi thử, luyện tập topik 1 , topik 2 ,' . $category->title;
        $this->baseView();
    }

    public function detailAction()
    {
        $category_slug = $this->dispatcher->getParam('category_slug');
        $lesson_slug = $this->dispatcher->getParam('lesson_slug');
        $this->view->category_slug = $category_slug;
        $this->view->lesson_slug = $lesson_slug;

        $category = Category::findFirst('slug="' . $category_slug . '"');
        if ($category == null) {
            $this->notFound();
            return;
        }

        $lesson = Lessons::findFirst('category_id = ' . $category->id . ' and slug="' . $lesson_slug . '"');
        if ($lesson == null) {
            $this->notFound();
            return;
        }
        $lesson->view++;
        $lesson->save();
        //next
        $next_lesson = Lessons::findFirst(
            [
                'category_id = ' . $lesson->category_id . ' and idx >' . $lesson->idx,
                'order' => 'idx ASC',
                'limit' => 1,
            ]
        );

        $this->view->category = $lesson->category;
        $this->view->lesson = $lesson;
        $this->view->next_lesson = $next_lesson;

        $this->title = $lesson->body . ' | ' . $lesson->category->title . ' hay nhất tại lovekorean';
        $this->description = $this->title . ' - Tuyển tập các bài ôn luyện ' . $lesson->category->title . ' tốt nhất dành cho du học sinh, lao động hàn quốc, luyện thi ' . $lesson->category->title;
        $this->keywords = 'Tài liệu miễn phí, bộ đề thi, thi thử, luyện tập, topik 1 , topik 2 ,' . $lesson->category->title . ' , ' . $lesson->body;
        $this->baseView();
    }

    public function resultAction()
    {
        $this->view->disable();
        $request = new Request();
        if (!$request->isPost() || !$request->isAjax()) {
            return;
        }
        $response = array();

        $lesson_id = $request->getPost('lesson_id');

        $lesson = Lessons::findFirst('id = ' . $lesson_id);
        if ($lesson == null) {
            $this->notFound();
            return;
        }
        $quiz = $request->getPost('quiz');
        $i = 0;
        $anwserTrue = array();
        $countTrue = 0;
        $countFalse = 0;
        foreach ($lesson->questions as $question) {
            $anwserTrue[$i] = $question->true_anwser;
            $anwser_idx = ($i < count($quiz) && $quiz[$i] != '') ? $quiz[$i] : -1;
            if ($anwser_idx == $question->true_anwser) {
                $countTrue++;
            } elseif ($anwser_idx != -1) {
                $countFalse++;
            }
            $i++;
        }
        $lesson->numdo++;
        $lesson->save();

        $response['total'] = $i;
        $response['countTrue'] = $countTrue;
        $response['countFalse'] = $countFalse;
        $response['noAnwser'] = count($anwserTrue) - $countTrue - $countFalse;
        $response['anwserTrue'] = $anwserTrue;
        $response['lesson_id'] = $lesson->id;

        echo json_encode($response);
    }

    public function reportAction()
    {
        $this->view->disable();
        $request = new Request();
        if ($request->isPost() && $request->isAjax()) {
            $model = new Report();
            $model->lesson_id = $request->getPost('lesson_id');
            $model->title = $request->getPost('title');
            $model->body = $request->getPost('body');
            $model->email = $request->getPost('email');
            if ($model->save()) {
                echo 'Success';
                return;
            }
            foreach ($model->getMessages() as $message) {
                echo $message;
            }
            echo 'Error save';
            return;
        }
        echo 'Error no post';
    }
}

