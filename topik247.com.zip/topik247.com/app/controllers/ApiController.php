<?php

use Phalcon\Http\Request;

class ApiController extends \Phalcon\Mvc\Controller
{

    public function initialize()
    {
        $this->view->setRenderLevel(\Phalcon\Mvc\View::LEVEL_ACTION_VIEW);
    }

    public function indexAction()
    {

    }

    public function categoryAction()
    {
        $categories = Category::find();
        $resp = array();
        foreach ($categories as $row) {
            $resp[] = array(
                'title' => $row->title,
                'slug' => $row->slug
            );
        }
        echo json_encode($resp);
    }

    public function lessonsAction($slug){
        $category = Category::findFirst('slug="' . $slug . '"');
        if ($category == null) {
            $this->notFound();
            return;
        }
        $resp = array();
        foreach ($category->lessons as $lesson){
            $resp[] = array(
                'body'=> $lesson->body,
                'slug'=> $lesson->slug,
                'view'=> $lesson->view,
                'numdo'=> $lesson->numdo
            );
        }
        echo json_encode($resp);
    }
    public function lessonAction($slug){
        $lesson = Lessons::findFirst('slug="' . $slug . '"');
        $resp = array(
            'body'=> $lesson->body,
            'slug'=> $lesson->slug,
            'view'=> $lesson->view,
            'numdo'=> $lesson->numdo
        );

        $questions = array();
        foreach ($lesson->questions as $question){
            $questions[] = array(
                'quota'=>$question->quota,
                'question'=>$question->question,
                'body'=>$question->body,
                'tip'=>$question->tip,
                'true_anwser'=>$question->true_anwser,
                'tmp' => $question->anwsers
            );
        }

        for ($i = 0; $i < count($questions);$i++){
            $questions[$i]['anwsers'] = array();
            foreach ($questions[$i]['tmp'] as $anwser){
                $questions[$i]['anwsers'][] = array(
                    'body' => $anwser->body,
                    'idx' => $anwser->idx,
                );
            }
            unset($questions[$i]['tmp']);
        }
        $resp['questions'] = $questions;

        echo json_encode($resp);
    }

    public function fbwebhookAction(){
//        file_put_contents(
//            'log.txt',
//            "\n" . file_get_contents('php://input'),
//            FILE_APPEND
//        );
        $token = "828864589:AAGwcucORTReIaRl0rtxiZbDsHf_Wr19hYU";
        $msg = 'New FB comment, check link:https://developers.facebook.com/tools/comments/676796769430884/approved/descending/';
        $group = "-1001477319729";

        $url = "https://api.telegram.org/bot".$token."/sendMessage?chat_id=@lovekoreanvn&text=".urlencode($msg);
        $res = file_get_contents($url);

        if ($_GET['hub_verify_token'] === 'make-up-a-token') {
            echo $_GET['hub_challenge'];
            return;
        }
        echo 'Error';
    }
}

