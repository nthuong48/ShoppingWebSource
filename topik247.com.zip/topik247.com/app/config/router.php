<?php

$router = $di->getRouter();

// Define your routes here
$route = $router->add(
    '/{category_slug:[a-zA-Z0-9_-]+}',
    [
        'controller' => 'lessons',
        'action'     => 'list',
    ]
);

$route = $router->add(
    '/{category_slug:[a-zA-Z0-9_-]+}/{lesson_slug:[a-zA-Z0-9_-]+}.html',
    [
        'controller' => 'lessons',
        'action'     => 'detail',
    ]
);

$router->handle();
