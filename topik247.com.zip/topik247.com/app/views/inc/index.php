<!DOCTYPE html>
<html lang="vi">
<head>

    <!-- Basic -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <title><?= $title ?></title>
    <meta name="Description" content="<?= $description ?>"/>
    <meta name="Keywords" content="<?= $keywords ?>"/>
    <base href="./"/>
    <link rel="shortcut icon" href="../favicon.ico" type="image/x-icon"/>
    <meta name="viewport" content="width=device-width,initial-scale=1.0,user-scalable=yes">
    <meta name="author" content="topik247.com">

    <meta property="og:url" content="https://topik247.com"/>
    <meta property="og:type" content="website"/>
    <meta property="og:title" content="Tổng hợp 300 đề luyện thi topik và bài tập tiếng hàn sơ cấp-trung cấp-cao cấp"/>
    <meta property="og:description"
          content="Tổng hợp 300 đề luyện thi topik và bài tập tiếng hàn sơ cấp-trung cấp-cao cấp"/>
    <meta property="og:image"
          content="https://scontent.fhan5-1.fna.fbcdn.net/v/t1.0-9/56416843_818421348521783_3641422854374817792_n.jpg?_nc_cat=109&_nc_oc=AQncoA2b6C1uGfBLWxtwKCZW7saQsfTq1n4HKxt1t1gVKR3Uejdf9LslWeKaUOhADsz4tv_CahuvJI5TsUAmVNQ8&_nc_ht=scontent.fhan5-1.fna&oh=f379ffd045039a96ca5d49835fc2caae&oe=5D3DB8BE"/>

    <link rel="stylesheet" href="../css/style.css" type="text/css"/>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="../js/vendor/modernizr.min.js"></script>
    <script src="../js/storage.js"></script>
    <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
    <script>
        (adsbygoogle = window.adsbygoogle || []).push({
            google_ad_client: "ca-pub-2143644439313117",
            enable_page_level_ads: true
        });
    </script>
    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-138152169-1"></script>
    <script>
        window.dataLayer = window.dataLayer || [];

        function gtag() {
            dataLayer.push(arguments);
        }

        gtag('js', new Date());

        gtag('config', 'UA-138152169-1');
    </script>
    <!--FB comment plugin monitor-->
    <meta property="fb:app_id" content="676796769430884"/>
    <meta property="fb:admins" content="100004830250761"/>
    <meta property="fb:admins" content="100025056966204"/>
    <meta property="fb:admins" content="100009088809970"/>
</head>

<body class="pg-gv-list">
<script>
    window.fbAsyncInit = function () {
        FB.init({
            appId: '676796769430884',
            xfbml: true,
            version: 'v3.2'
        });
        FB.AppEvents.logPageView();
    };

    (function (d, s, id) {
        var js, fjs = d.getElementsByTagName(s)[0];
        if (d.getElementById(id)) {
            return;
        }
        js = d.createElement(s);
        js.id = id;
        js.src = "https://connect.facebook.net/en_US/sdk.js";
        fjs.parentNode.insertBefore(js, fjs);
    }(document, 'script', 'facebook-jssdk'));
</script>

<div class="page page-sidebar-left">
    <header id="header" class="header fixed-top">
        <button id="sidenav-toggle" class="header-sidenav-toggle hamburger hamburger--slider fl ml-3">
            <span class="hamburger-box d-block"><span class="hamburger-inner"></span></span>
        </button>
        <a class="header-logo-link ml-1" href="/">
            <img class="header-logo-img" src="../images/logo.png" alt="">
        </a>
        <div id="header-search-main" class="header-search-main fr mr-3">
            <div id="search-main" class="search-main">
                <form action="https://www.google.com/cse" name="search_box" target="_blank">
                    <input type="hidden" value="013868285578214843420:ixyedi7gtei" name="cx">
                    <div class="input-group input-group-lg">
                        <input type="text" class="search-main-input form-control" name="q"
                               placeholder="Tìm kiếm">
                        <div class="input-group-append">
                            <button type="submit" class="search-main-btn btn" onclick="document.search_box.submit()">
                                <i class="icont-search"></i>
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </header>

    <div class="page-main">
        <?php include 'sidebar-left.php'; ?>
        <div class="container">
            <?php echo $this->getContent(); ?>
        </div>

        <aside class="ads">
            <div class="fb-page fr mr-2"
                 data-href="https://www.facebook.com/lovekoreanvn"
                 data-width="300"
                 data-hide-cover="false"
                 data-show-facepile="true"></div>
        </aside>
    </div>

    <?php include 'footer.php'; ?>
</div>

<a id="back-to-top" class="backtotop btn" href="#">
    <i class="zmdi zmdi-chevron-up"></i>
</a>

<!--Vendor-->
<!--<script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script>-->
<script src="../js/vendor/jquery.min.js"></script>
<script src="../js/vendor/popper.min.js"></script>
<script src="../js/vendor/bootstrap.min.js"></script>
<script src="../js/vendor/jquery.mCustomScrollbar.concat.min.js"></script>
<script src="../js/vendor/headroom.min.js"></script>
<script src="../js/vendor/jQuery.headroom.min.js"></script>
<script src="../js/vendor/waves.min.js"></script>

<!--Base-->
<script src="../js/plugins.js"></script>
<script src="../js/main.js"></script>

</body>
</html>