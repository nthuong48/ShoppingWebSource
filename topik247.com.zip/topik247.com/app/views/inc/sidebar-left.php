<aside id="sidebar-left" class="sidebar sidebar-left">
    <div class="sidebar-scroll">
        <h3 class="sidebar-header">MỤC LỤC</h3>

        <nav class="nav-side">
            <ul class="nav nav-with-icon flex-column">
                <?php
                foreach ($categories as $category) {
                    $url = '/'.$category->slug;
                    $active =  isset($category_slug) && $category_slug == $category->slug ? 'active' : '';
                    ?>
                    <li class="nav-item <?=$active?>">
                        <a class="nav-link" href="<?= $url ?>">
                                        <span class="nav-icon">
                                            <span class="thumbnail thumbnail-hover-fadeout rounded-circle wf-30">
                                                <img class="lazy media-thumbnail-img img-fluid w-100"
                                                     src="../static/icons/c<?= $category->id ?>.png" alt="">
                                            </span>
                                        </span>
                            <?= $category->title; ?>
                        </a>
                    </li>
                <?php } ?>
            </ul>
        </nav>
    </div>

    <button id="sidebar-close" class="sidebar-close hamburger hamburger--slider is-active m-0 d-xl-none">
        <span class="hamburger-box d-block"><span class="hamburger-inner"></span></span>
    </button>
</aside>