<div class="modal fade" id="reportModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
     aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <form>
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Báo lỗi</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <input type="hidden" class="form-control" id="" name="lesson_id"
                           aria-describedby="" value="<?=$lesson->id?>">
                    <div class="form-group">
                        <label for="exampleInputEmail1">Tiêu đề</label>
                        <input type="text" class="form-control" id="" name="title"
                               aria-describedby="" placeholder="">
                        <!--                        <small id="emailHelp" class="form-text text-muted">We'll never share your email with-->
                        <!--                            anyone else.-->
                        </small>
                    </div>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Nội dung</label>
                        <textarea type="text" class="form-control" id="" name="body" rows="2"
                                  aria-describedby="" placeholder=""></textarea>
                        <!--                        <small id="emailHelp" class="form-text text-muted">We'll never share your email with-->
                        <!--                            anyone else.-->
                        </small>
                    </div>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Email (Không bắt buộc )</label>
                        <input type="email" class="form-control" id="" name="email"
                               aria-describedby="emailHelp" placeholder="">
                        <!--                        <small id="emailHelp" class="form-text text-muted">We'll never share your email with-->
                        <!--                            anyone else.-->
                        </small>
                    </div>

                </div>
                <div class="modal-footer">
                    <!--                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>-->
                    <button type="button" id="submitReport" class="btn btn-primary">Gửi</button>
                </div>
            </form>
        </div>
    </div>
</div>