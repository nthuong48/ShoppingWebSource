<div class="modal fade" id="modalCheckResult" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
     aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Kết quả</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div>
                    <!--                    <div>-->
                    <!--                        <a class="">Điểm</a>-->
                    <!--                        <p>7</p>-->
                    <!--                    </div>-->
                    <div>
                        <a class="pt-2"><b id="resultTotal"></b></a>
                        <p id="resultWarning"></p>
                    </div>
                </div>
                <table class="table table-bordered ">
                    <thead>
                    <tr class="table-info">
                        <th scope="col"></th>
                        <th scope="col">Trả lời đúng</th>
                        <th scope="col">Trả lời sai</th>
                        <th scope="col">Không trả lời</th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr>
                        <th scope="row">Kết quả</th>
                        <td id="true">0</td>
                        <td id="false">0</td>
                        <td id="noanwser">0</td>
                    </tr>
                    </tbody>
                </table>
            </div>
            <div class="modal-footer">
                <button type="button" id="viewResult" class="btn btn-gray-500">Xem đáp án</button>
                <?php
                echo $totalTip > 0 ? '<a class="btn btn-gray-500 fl ml-1" id="showTip">Xem gợi ý</a>' : '';
                echo '<a class="btn btn-gray-500 fr mr-1" id="" href="' . $shareUrl . '">Làm lại</a>';
                if ($next_lesson) {
                    $url = '/' . $category->slug . '/' . $next_lesson->slug . '.html';
                    echo '<a class="btn btn-primary text-uppercase fr" href="' . $url . '">Bài tiếp</a>';
                }
                ?>
            </div>
        </div>
    </div>
</div>