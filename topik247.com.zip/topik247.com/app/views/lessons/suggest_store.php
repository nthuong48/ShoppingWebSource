<div class="box-store mb-4 my-4">
    <p>Hãy like fanpage của chúng tôi để thảo luận và cập nhật thêm nhiều bài tập hơn </p>
    <div class="fb-page"
         data-href="https://www.facebook.com/lovekoreanvn"
         data-width="250"
         data-hide-cover="false"
         data-show-facepile="true"></div>
<!--    <p>Đã có app --><?//=$project_name?><!-- trên điện thoại. Tải App để chúng tôi phục vụ-->
<!--        tốt hơn.</p>-->
<!--    <h3 class="box-store-title mb-1">-->
<!--        Tải --><?//=$project_name?>
<!--        <a href="#">-->
<!--            cho Android <img class="box-store-google mx-1" src="images/icons/google-play.png" alt="">-->
<!--        </a>-->
<!--        <a href="#">-->
<!--            cho Iphone-->
<!--            <img class="box-store-apple mx-1" src="images/icons/apple-store.png" alt="">-->
<!--        </a>-->
<!--    </h3>-->

    <div class="mb-2">
<!--        <img src="images/ex/social-2.png" alt="">-->
<!--        <div class="fb-like" data-href="--><?//= $shareUrl; ?><!--" data-layout="button_count" data-action="like" data-size="large" data-show-faces="true" data-share="true"></div>-->
        <div
                class="fb-like"
                data-share="true"
                data-width="250"
                data-show-faces="true">
        </div>
    </div>

    <p class="mb-0">Loạt bài <b>ôn luyện Tiếng hàn Sơ cấp, Tiếng hàn Trung Cấp, Tiếng hàn Cao Cấp, Từ vựng Tiếng hàn .. </b> của
        chúng tôi được biên soạn bám sát nội dung thi Topik giúp bạn củng cố và ôn luyện kiến
        thức tốt nhất cho các kì thi Topik.</p>
</div>