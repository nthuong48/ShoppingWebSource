<?php
$shareUrl = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
//$arrIdx = array('(A)','(B)','(C)','(D)');
?>

<script>

    var result = [];
    var anwserTrue = [];

    function clickRadio(elmnt) {
        var n, i, x, q;
        n = elmnt.value;
        q = elmnt.id;
        for (i = 0; i < 4; i++) {
            x = document.getElementById("label" + q + "_" + i);
            if (x) {
                x.className = x.className.replace(" checkedlabel", "");
            }
        }
        result[q] = n;
        document.getElementById("label" + q + "_" + n).className += " checkedlabel";
    }
</script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script>
    function hasClass(element, className) {
        return (' ' + element.className + ' ').indexOf(' ' + className + ' ') > -1;
    }

    function showTip() {
        $("tip").removeClass("hide");
    }

    function alertReportSuccess() {
        $('#reportModal').modal('hide');
        alert("Cảm ơn bạn đã góp ý, LoveKorean luôn lắng nghe và cập nhật để phục vụ các bạn tốt nhất !");
    }

    $(document).ready(function () {
        $("a#showTip").click(function () {
            $("div").removeClass("hide");
        });
        $("button#viewResult").click(function () {
            var i, j, x, isTrue;
            for (j = 0; j < anwserTrue.length; j++) {
                isTrue = j < result.length && result[j] == anwserTrue[j];
                for (i = 0; i < 4; i++) {
                    x = document.getElementById("label" + j + "_" + i);
                    if (x) {
                        if (anwserTrue[j] == i) {
                            document.getElementById("label" + j + "_" + i).className += " true_anwser";
                        }
                        if (anwserTrue[j] != i && hasClass(document.getElementById("label" + j + "_" + i), "checkedlabel")) {
                            document.getElementById("label" + j + "_" + i).className += " false_anwser";
                        }
                        if (!hasClass(x, "checkedlabel")) {
                            x.removeChild(x.childNodes[1]);
                        }
                    }
                }
            }
            var elem = document.getElementById("viewResult");
            var par = elem.parentNode;
            par.removeChild(elem);
            $("#modalCheckResult").modal('hide');
        });
        $("button#submitReport").click(function () {
            var formData = {
                'title': $('input[name=title]').val(),
                'body': $('textarea[name=body]').val(),
                'email': $('input[name=email]').val(),
                'lesson_id': $('input[name=lesson_id]').val()
            };
            $.ajax({
                type: "POST",
                url: "/lessons/report",
                data: formData,
                success: function (result) {
                    alertReportSuccess();
                }
            });
        });
        $("button#btnViewResult").click(function () {
            var formData = {
                'lesson_id': $('input[name=lesson_id]').val(),
                'quiz': result,
            };
            $.ajax({
                type: "POST",
                url: "/lessons/result",
                data: formData,
                success: function (result) {
                    var obj = JSON.parse(result);
                    setLessonFinish(obj.lesson_id, obj.countTrue);
                    anwserTrue = obj.anwserTrue;
                    var rate = obj.countTrue / obj.total;
                    var warning = 'Quá xuất sắc,hãy thử sức ở bài tiếp nhé !';
                    $("b#resultTotal").html("Đúng:" + obj.countTrue + "/" + obj.total);
                    if (rate < 0.8) {
                        warning = 'Tạm được, hãy cố hoàn thành nốt các câu còn lại nhé !';
                    }
                    if (rate < 0.5) {
                        warning = 'Cố gắng hết mình lên nào!!!';
                    }
                    $("p#presultWarning").html(warning);
                    $("td#true").html(obj.countTrue);
                    $("td#false").html(obj.countFalse);
                    $("td#noanwser").html(obj.noAnwser);
                    $("a#btnNext").removeClass("hide");
                }
            });
        });
    });
</script>

<div class="card card-1 mt-1">
    <h1 class="title-2 mb-4 card-body pb-0"><?= $lesson->body . ' | ' . $category->title ?></h1>
    <hr class="divider-1 my-0">
    <div class="card-body">
        <input type="hidden" name="lesson_id" value="<?= $lesson->id ?>">
        <?php
        $i = 0;
        $totalTip = 0;
        foreach ($lesson->questions as $quesion) {
            $ques_id = $quesion->id;
            ?>
            <div>
                <?php if ($quesion->quota != null && $quesion->quota != '' && $i > 0) {
                    echo '<br/><br/>';
                } ?>
                <?php if ($quesion->quota != null && $quesion->quota != '') { ?>
                    <div class="bg-gray-200 border-top px-4 py-3 mb-1">
                        <?= $quesion->quota ?>
                    </div>
                    <?php
                } ?>
                <p class="title-4 font-family-base mb-0 question"><?= ($i + 1) . '.' . ($quesion->question) ?></p>
                <p class="title-4 font-family-base mb-0"><?= $quesion->body ?></p>
                <div id="question_<?= $ques_id ?>" class="altcontainer">
                    <?php
                    $k = 0;
                    foreach ($quesion->anwsers as $anwser) { ?>
                        <label class="radiocontainer"
                               id="label<?= $i . '_' . $anwser->idx ?>"> <?= $anwser->body ?>
                            <input
                                    type="radio" name="quiz<?= $i ?>" id="<?= $i ?>"
                                    onclick="clickRadio(this)"
                                    value="<?= $anwser->idx ?>">
                            <span class="checkmark <?= isset($anwserSubmit[$ques_id]) && $anwserSubmit[$ques_id] == $anwser->idx ? 'selected' : '' ?>"></span></label>
                        <?php
                        $k++;
                    }
                    ?>
                </div>
                <?php
                if ($quesion->tip != null && $quesion->tip != '') {
                    $totalTip++;
                    ?>
                    <div class="bg-info border-top px-4 py-3 mb-1 tip hide" id="">
                        <p class="title-3 font-family-base mb-0">Gợi ý trả lời</p>
                        <p class="title-4 font-family-base mb-0"><?= $quesion->tip ?></p>
                    </div>
                    <?php
                }
                ?>
            </div>
            <br>
            <?php
            $i++;
        }
        ?>
        <hr class="divider-1 my-4">
        <div class="text-center h30">
            <button type="button" class="btn btn-gray-500 fl" data-toggle="modal" data-target="#reportModal">Báo
                lỗi
            </button>
            <button type="button" class="btn btn-gray-500 fl ml-1" onclick="javascript:window.print()"
                    href="javascript:window.print()">In bài
            </button>
            <button type="button" class="btn btn-primary text-uppercase fr" id="btnViewResult" data-toggle="modal"
                    data-target="#modalCheckResult">Xem kết quả
            </button>
        </div>
        <?php include('comment-fb.php') ?>
        <?php include('suggest_store.php') ?>
        <?php include('form_report.php') ?>
        <?php include('modal_result.php') ?>
    </div>
</div>