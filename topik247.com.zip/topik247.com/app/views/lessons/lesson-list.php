<div class="card card-1 shadow-none bg-transparent">
    <div class="card-header flex-column justify-content-center align-items-start border-0">
        <h1 class="title-2 mb-1"><?= $category->title . ' | Luyện tập ' . $category->title . ' | Trắc nghiệm ' . $category->title ?></h1>
        <p class="small text-muted fw-4 lh-heading mb-0">Tổng hợp những bài ôn luyện trắc
            nghiệm <?= $category->title ?> tốt
            nhất phục vụ các bạn thi topik, lao động và du học Hàn quốc </p>
    </div>

    <div class="row grid-20px">
        <?php foreach ($lessons as $lesson) {
            $total[$lesson->id] = count($lesson->questions);
            $url = $category->slug . '/' . $lesson->slug . '.html';
            $rate = rand(3, 5);//$lessons[$i]['rate'];
            ?>
            <div class="col-lg-4 col-md-6">
                <div class="media media-gv">
                    <a class="thumbnail thumbnail-hover-fadeout rounded-circle wf-50 align-self-center mr-2"
                       href="<?= $url ?>">
                        <?php
                        if ($lesson->icon != -1) { ?>
                            <img class="lazy media-thumbnail-img img-fluid"
                                 src="static/icons/l<?= $lesson->icon ?>.jpg"
                                 alt="">
                        <?php }
                        ?>
                    </a>

                    <div class="media-body align-self-center pl-1">
                        <h6 class="media-title text-truncate mb-0">
                            <a class="title-3 text-truncate" href="<?= $url ?>"><?= $lesson->body; ?></a>
                        </h6>

                        <div class="rating mr-2">
                            <div class="list-inline list-inline-star">
                                <?php for ($j = 0; $j < 5; $j++) {
                                    $cl = $j <= $rate ? 'text-secondary' : 'text-gray-500';
                                    echo '<span class="list-inline-item">
<i class="zmdi zmdi-star ' . $cl . '"></i>
</span>';
                                } ?>
                            </div>

                            <span class="text-gray-500 lh-heading mx-2"></span>
                            <img class="" src="images/icons/view.png" alt="">
                            <small class="rating-text"><?= $lesson->view; ?></small>
                        </div>
                        <br>
                        <a class="progress_point" id="<?= $lesson->id ?>"></a>/<a
                                id="total_<?= $lesson->id ?>"><?= count($lesson->questions) ?></a>
                        <div class="progress"  style="height: 5px;">
                            <div class="progress-bar bg-danger" id="progressbar_<?= $lesson->id ?>" role="progressbar" style="width: 0%;" aria-valuenow="0"
                                 aria-valuemin="0" aria-valuemax="100"></div>
                        </div>
                    </div>
                </div>
            </div>
        <?php } ?>
    </div>
</div>

<script>
    var progress_point = document.getElementsByClassName("progress_point");
    for (var i = 0; i < progress_point.length; i++) {
        var id = progress_point[i].id;
        var cur = getLessonFinish(id);
        $("a#" + id).html(cur);
        var total = $("a#total_" + id).html();
        var elem = document.getElementById("progressbar_" + id);
        var rate = Math.round(cur / total * 100);
        if (elem) {
            elem.style.width = rate + "%";
            if(rate == 100){
                elem.className = elem.className.replace(" bg-danger","");
                elem.className += " bg-success";
            }
        }
    }
</script>