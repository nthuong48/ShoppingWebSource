<?php
		$token = "828864589:AAGwcucORTReIaRl0rtxiZbDsHf_Wr19hYU";
        $msg = json_encode($_POST);
        $group = "-1001477319729";
        $msg = 'Co khach';

        $url = "https://api.telegram.org/bot".$token."/sendMessage?chat_id=@lovekoreanvn&text=".urlencode($msg);
        $res = file_get_contents($url);

        if ($_GET['hub_verify_token'] === 'abc123') {
            echo $_GET['hub_challenge'];
            return;
        }
        echo 'Error';
?>