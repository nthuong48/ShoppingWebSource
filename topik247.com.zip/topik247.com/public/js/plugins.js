// Avoid `console` errors in browsers that lack a console.
(function() {
    var method;
    var noop = function () {};
    var methods = [
        'assert', 'clear', 'count', 'debug', 'dir', 'dirxml', 'error',
        'exception', 'group', 'groupCollapsed', 'groupEnd', 'info', 'log',
        'markTimeline', 'profile', 'profileEnd', 'table', 'time', 'timeEnd',
        'timeline', 'timelineEnd', 'timeStamp', 'trace', 'warn'
    ];
    var length = methods.length;
    var console = (window.console = window.console || {});

    while (length--) {
        method = methods[length];

        // Only stub undefined methods.
        if (!console[method]) {
            console[method] = noop;
        }
    }
}());

// Place any jQuery/helper plugins in here.

$(document).ready(function() {

    // -------------------------
    // headroom
    // -------------------------

    $("#header").headroom({
        offset: 100,
        tolerance : {
            up : 10,
            down : 0
        }
    });

    // -------------------------
    // mCustomScrollbar
    // -------------------------

    var $mcs = $('.mcs'),
        $mcs_horizontal = $('.mcs-horizontal');

    $mcs.mCustomScrollbar({
        autoExpandScrollbar: true,
        mouseWheel: {
            preventDefault: true
        }
    });

    $mcs_horizontal.mCustomScrollbar({
        axis:"x",
        // autoExpandScrollbar: true,
        advanced:{ autoExpandHorizontalScroll:true },
        // autoHideScrollbar: true,
        scrollButtons: {
            enable: true
        }

    });


    if ($(window).width() < 992) {
        // mCustomScrollbar destroy
        $mcs.mCustomScrollbar("destroy");
        $mcs_horizontal.mCustomScrollbar("destroy");
    }


    // -------------------------
    // Waves
    // -------------------------

    Waves.attach('.nav-side .nav-link ');
    Waves.init();

});