$(document).ready(function(){

    //==
    // loading
    //

    // setTimeout(function () {
    //     $("#loader").fadeOut(300, function () {
    //         $(this).remove();
    //     });
    //     // $('body').removeClass('inactive');
    //     // $('html,body').scrollTop(0);
    // }, 100);


    // -------------------------
    // back to top
    // -------------------------

    var $bactotop = $('#back-to-top');
    if ($bactotop.length) {
        var scrollTrigger = 200, // px
            backToTop = function () {
                var scrollTop = $(window).scrollTop();
                if (scrollTop > scrollTrigger) {
                    $bactotop.addClass('backtotop-show');
                } else {
                    $bactotop.removeClass('backtotop-show');
                }
            };
        backToTop();
        $(window).on('scroll', function () {
            backToTop();
        });
        $bactotop.on('click', function (e) {
            e.preventDefault();
            $('html, body').animate({
                scrollTop: 0
            }, 700);
        });
    }


    // -------------------------
    // search main
    // -------------------------

    var $search_main = $('#search-main'),
        $search_main_input = $search_main.find('.search-main-input'),
        $search_main_result = $search_main.find('.search-main-result');

    // show search result
    $search_main_input.on('focus', function () {
        $search_main_result.show();
    });

    $search_main_result.find('.list-group .list-group-item').on('click', function (e) {
        e.preventDefault();
        $search_main_input.val($(this).text());
        $search_main_result.hide();
    });

    // close click body
    $(document).mouseup(function(e) {
        if (!$search_main_input.is(e.target) && $search_main_input.has(e.target).length === 0) {
            $search_main_result.hide();
        }
    });

    $('#header-search-toggle').on('click', function (e) {
        e.preventDefault();
        $('#header-search-main').addClass('opened');
    });

    $('#header-search-main-close').on('click', function (e) {
        e.preventDefault();
        $('#header-search-main').removeClass('opened');
    });

    // $(window).scroll(function(){
    //     $search_main_result.hide();
    //     $search_main.find('.show').removeClass('show');
    // });


    // -------------------------
    // menu left
    // -------------------------

    var breakpoint_mobile = 1200;

    if ($(window).width() < breakpoint_mobile) {

        // toggle mobile
        var $sidebar_left = $('#sidebar-left'),
            $sidenav_toggle = $('#sidenav-toggle');

        $sidenav_toggle.on('click', function (e) {
            e.preventDefault();

            $sidebar_left.toggleClass('open');
            // $(this).toggleClass('is-active');

            if ($sidebar_left.hasClass('open')) {
                $('body').prepend('<div id="sidebar-overlay" class="sidebar-overlay"></div>');

                $('#sidebar-overlay').fadeIn(300).on('click', function () {
                    close_sidebar_left();
                });
            } else {
                close_sidebar_left();
            }

        });

        $('#sidebar-close').on('click', function () {
            close_sidebar_left();
        });

        function close_sidebar_left() {
            $sidebar_left.removeClass('open');
            $('#sidebar-overlay').fadeOut(300, function () {
                $(this).remove();
            });
            // $sidenav_toggle.removeClass('is-active');
        }
    }
});